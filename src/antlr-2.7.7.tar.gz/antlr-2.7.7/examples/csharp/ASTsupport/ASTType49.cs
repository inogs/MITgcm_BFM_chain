/// <summary>Test heterogeneous dynamic typing class.</summary>
public class ASTType49 : antlr.CommonAST 
{
}
