NCO on Fedora and Red Hat
=========================

NCO provides bld/nco.spec for building Fedora RPMs.
It has been tested on FC1--FC6 for both the i386 and x64_64
architectures.

For pre-built binaries and SRPMs, please see:

http://nco.sf.net#rpm

