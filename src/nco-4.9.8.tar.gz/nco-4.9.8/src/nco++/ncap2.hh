#ifndef NCAP2_HH
#define NCAP2_HH

typedef enum { ncap_var, 
               ncap_att,
               ncap_xpr_var_hyp,
               ncap_xpr_att_hyp,
               ncap_xpr_var_cst,
	       ncap_xpr_null
              } ncap_type;

#endif // NCAP2_HH
